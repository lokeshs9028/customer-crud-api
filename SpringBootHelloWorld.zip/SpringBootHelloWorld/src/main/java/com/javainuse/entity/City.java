package com.javainuse.entity;

import javax.persistence.*;

@Entity
public class City {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cityId;

    private String city_name;

    // Add a reference to state
    // Assume a Many-to-One relationship: many cities belong to one state
    @ManyToOne
    @JoinColumn(name = "stateid")
    private State state;

    // Constructors
    public City() {
    }

    public City(String city_name, State state) {
        this.city_name = city_name;
        this.state = state;
    }

    // Getters and Setters
    public Long getcityId() {
        return cityId;
    }

    public void setcityId(Long cityid) {
        this.cityId = cityid;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }
}
