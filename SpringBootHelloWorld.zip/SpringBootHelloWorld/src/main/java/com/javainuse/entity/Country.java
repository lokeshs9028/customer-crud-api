package com.javainuse.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

@Entity
public class Country {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long countryId;

    private String country_name;

    // Add a reference to states
    // Assume a One-to-Many relationship: one country has many states
    @OneToMany(mappedBy = "country")
    @JsonIgnore
    private List<State> states;

    // Constructors
    public Country() {
    }

    public Country(String country_name) {
        this.country_name = country_name;
    }

    // Getters and Setters
    public Long getCountryId() {
        return this.countryId;
    }

    public void setCountryId(Long countryid) {
        this.countryId = countryid;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public List<State> getStates() {
        return states;
    }

    public void setStates(List<State> states) {
        this.states = states;
    }
}
