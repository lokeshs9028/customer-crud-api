package com.javainuse.entity;

import javax.persistence.*;

@Entity
public class State {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long stateId;

    private String state_name;

    // Add a reference to country
    // Assume a Many-to-One relationship: many states belong to one country
    @ManyToOne
    @JoinColumn(name = "countryid")
    private Country country;

    // Constructors
    public State() {
    }

    public State(String state_name, Country country) {
        this.state_name = state_name;
        this.country = country;
    }

    // Getters and Setters
    public Long getstateId() {
        return this.stateId;
    }

    public void setstateid(Long stateid) {
        this.stateId = stateid;
    }

    public String getState_name() {
        return state_name;
    }

    public void setState_name(String state_name) {
        this.state_name = state_name;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}
