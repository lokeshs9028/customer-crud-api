package com.javainuse.entity;

import javax.persistence.*;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String productName;
    private int quantity;
    private double price;
    private String prodDesc;
    private String image;

    public Product(String productName, int quantity, double price, String prodDesc, String image) {
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
        this.prodDesc = prodDesc;
        this.image = image;
    }

    public Product() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setprodDesc(String prodDesc) {
        this.prodDesc = prodDesc;
    }

    public String getprodDesc() {
        return prodDesc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

}
