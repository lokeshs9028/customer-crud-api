package com.javainuse.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javainuse.entity.City;
import java.util.*;

// CityRepository.java
public interface CityRepository extends JpaRepository<City, Long> {
    List<City> findByStateStateId(Long stateId);

}
