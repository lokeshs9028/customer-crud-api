package com.javainuse.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javainuse.entity.Country;

// CountryRepository.java
public interface CountryRepository extends JpaRepository<Country, Long> {
}
