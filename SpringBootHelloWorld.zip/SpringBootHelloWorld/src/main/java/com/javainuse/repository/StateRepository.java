package com.javainuse.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javainuse.entity.State;
import java.util.*;

// StateRepository.java
public interface StateRepository extends JpaRepository<State, Long> {
    List<State> findByCountryCountryId(Long countryid);
}
