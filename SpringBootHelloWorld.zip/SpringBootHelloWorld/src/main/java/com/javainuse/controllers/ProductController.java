package com.javainuse.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javainuse.entity.Product;
import com.javainuse.repository.ProductRepository;

@Controller
@RequestMapping(path = "/")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    // Creating new product
    @PostMapping(path = "/add")
    public String addNewProduct(@ModelAttribute Product product) {
        productRepository.save(product);
        return "redirect:/";
    }

    // Get all products
    @GetMapping(path = "/")
    public String getAllProducts(Model model) {
        Iterable<Product> products = productRepository.findAll();
        model.addAttribute("products", products);
        return "productList";
    }

    // Get new product Form
    @GetMapping(path = "/add")
    public String newProductForm() {
        return "new";
    }

    // Get editProduct form
    @GetMapping(path = "/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        // Long id2 = Long.parseLong(id);
        Product product = productRepository.findOne(id);
        model.addAttribute("product", product);
        return "editForm";
    }

    // Update product form
    @PostMapping(path = "/submitEdit")
    public String updateProduct(@ModelAttribute Product product) {
        productRepository.save(product);
        return "redirect:/";
    }

    // Delete product
    @GetMapping(path = "/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        // Long id2 = Long.parseLong(id);
        productRepository.delete(id);
        return "redirect:/";

    }
}
