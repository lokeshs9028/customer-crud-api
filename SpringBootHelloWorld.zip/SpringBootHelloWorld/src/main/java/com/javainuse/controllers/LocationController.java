package com.javainuse.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javainuse.entity.City;
import com.javainuse.entity.Country;
import com.javainuse.entity.State;
import com.javainuse.repository.CityRepository;
import com.javainuse.repository.CountryRepository;
import com.javainuse.repository.StateRepository;

// LocationController.java
@Controller
public class LocationController {

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private CityRepository cityRepository;

    // Get all countries
    @GetMapping(path = "/locations")
    public String getLocation() {
        return "locations";
    }

    @GetMapping(path = "/getCountries")
    public @ResponseBody List<Country> getCountries(Model model) {
        List<Country> countries = countryRepository.findAll();
        model.addAttribute("countries", countries);
        for (Country country : countries) {
            System.out.println(country.getCountry_name());
        }
        return countries;
    }

    @GetMapping(path = "/getStates/{countryId}")
    public @ResponseBody List<State> getStates(@PathVariable Long countryId) {
        List<State> states = stateRepository.findByCountryCountryId(countryId);
        for (State state : states) {
            System.out.println(state.getState_name());
        }

        return states;
    }

    @GetMapping(path = "/getCities/{stateId}")
    public @ResponseBody List<City> getCities(@PathVariable Long stateId) {
        List<City> cities = cityRepository.findByStateStateId(stateId);
        for (City city : cities) {
            System.out.println(city.getCity_name());
        }
        return cities;
    }

}
