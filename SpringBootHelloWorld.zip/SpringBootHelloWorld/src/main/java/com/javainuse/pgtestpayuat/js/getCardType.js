/*
Visa- 4
mastercard - 2 or 5
union pay- 62
american express- 37 or 34 and .number.length=15
discover = always 6
*/



const getCardType = (cn) => {
  let number = String(cn);
  if (String(number).match(new RegExp("^4")) !== null) {
    return "Visa";
  } else if (
    /^(5[1-5][0-9]{14}|2(22[1-9][0-9]{12}|2[3-9][0-9]{13}|[3-6][0-9]{14}|7[0-1][0-9]{13}|720[0-9]{12}))$/.test(
      number
    )
  ) {
    return "Mastercard";
  } else if (number.match(new RegExp("^3[47]")) !== null) {
    return "AMEX";
  } else if (
    number.match(
      new RegExp(
        "^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)"
      )
    ) !== null
  ) {
    return "Discover";
  } else if (number.match(new RegExp("^36")) !== null) {
    return "Diners";
  } else if (number.match(new RegExp("^30[0-5]")) !== null) {
    return "Diners - Carte Blanche";
  } else if (number.match(new RegExp("^35(2[89]|[3-8][0-9])")) !== null) {
    return "JCB";
  } else if (
    number.match(new RegExp("^(4026|417500|4508|4844|491(3|7))")) !== null
  ) {
    return "Visa Electron";
  }
  return "";
};

console.log(getCardType(6523263504173989));
